var storyModel = require('models/story');
var slug = require('slug');
var express = require('express');
var router = express.Router();
router.post('/',isAllow,create);
router.get('/(:page([1-9]+))?', getAll);
router.put('/:id',isAllow,update);
router.get('/:id',isAllow,details);
router.get('/post/:id',postDetails);
router.delete('/:id',isAllow,storyDelete);
module.exports = router;
function isAllow(req, res,next){
	if(req.session.user && req.session.user.userRole == 'author'){
		return next();
	}
	else
	{
		res.status(403).send({"status":"0","message":"forbidden"});
	}
}
function getAll(req, res) {
	let skip = req.params.page > 1 ?  (req.params.page-1)*req.app.locals.maxSize : 0;
	let condition = {};
	storyModel.countDocuments(condition, function(err, totalCount) {
           if(totalCount)
		   {
			   storyModel.find({},{title:1,slug:1,content:1,addedOn:1},{ skip: skip, limit: req.app.locals.maxSize },function (err, docs) {
					if(err)
						res.status(200).send({"status":"0","posts":[],totalCount:0});
				else
					res.status(200).send({"status":"1","posts":docs,totalCount:totalCount});
				});
		   }
		   else
		   {
			  res.status(200).send({"status":"0","posts":[],totalCount:totalCount}); 
		   }
		   
      });
}
function create(req, res) {
	 
	 if(!req.body.title)
	 {
		 res.status(200).send({"status":"0","message":"title should not be empty"});
	 }
	 else if(!req.body.content)
	 {
		 res.status(200).send({"status":"0","message":"content should not be empty"});
	 }
	 else
	 {	 
		var story = new storyModel(
			{
				title: req.body.title,
				slug: slug(req.body.title),
				content: req.body.content,
				authorId: req.session.user.userId,
				addedOn:new Date()
			}
		);
		story.save(function (err) {console.log(err);
			if (err) {
				res.status(200).send({ "status": "0", "message": err });
			}
			res.status(200).send({ "status": "1", "message": "Story created successfully!" });
		});
	 }
};

 function update(req, res) {
     storyModel.findById(req.params.id,function (err, doc) {
        if (err) 
		{
			res.status(200).send({ "status": "0", "message": err });
		}		
		if(req.body.content)
		{
			doc.content =  req.body.content;
		}
		if(req.body.title)
		{
			doc.title =  req.body.title;
		}
		doc.updatedOn =  new Date();
		doc.save();
		res.status(200).send({ "status": "1", "message": "Story updated successfully!" });
    });
 }
 function storyDelete(req, res) 
 {
	 storyModel.findByIdAndRemove(req.params.id, function (err) {
        if (err) res.status(200).send({ "status": "0", "message": err });
		res.status(200).send({ "status": "1", "message": "Story deleted successfully!" });
    });
 }
 
 function details(req, res) {
     storyModel.findById(req.params.id,function (err, doc) {
        if (err) 
		{
			res.status(200).send({ "status": "0", "post": [] });
		}
		else
		{
			res.status(200).send({ "status": "1", "post": doc });
		}
    });
 }
 function postDetails(req, res) {
     storyModel.findOne({slug:req.params.id},{title:1,slug:1,content:1,addedOn:1},function (err, doc) {
        if (err) 
		{
			res.status(200).send({ "status": "0", "post": [] });
		}
		else
		{
			res.status(200).send({ "status": "1", "post": doc });
		}
    });
 }
 