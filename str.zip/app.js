require('rootpath')();
const express = require('express');
var session = require('express-session');
const config = require('config');
const jwt = require('_helpers/jwt');
const errorHandler = require('_helpers/error-handler');
const bodyParser = require('body-parser');
const app = express();
// Set up mongoose connection
const mongoose = require('mongoose');
mongoose.connect(config.connectionString, {useNewUrlParser: true});
mongoose.Promise = global.Promise;
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
app.set('view engine', 'ejs');
//console.log(__dirname + '/views');
app.set('views','views');
// set the static files location 
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
var MongoDBStore = require('connect-mongodb-session')(session);
var store = new MongoDBStore({uri:config.connectionString,collection: 'tbl_session'});
app.use(session({ secret: config.appsecret, cookie: {maxAge: 1000 * 60 * 60 * 24 * 7},store: store, resave: true, saveUninitialized: false }));
app.use('/api', jwt(),require('routes/api'));
app.locals.maxSize = config.maxSize;
app.locals.settings = config.settings;
app.use(function (req, res, next) {
	res.locals = {
     token: config.apptoken,
     userRole: 'normal',
	 user:{}
   };
   if(req.session && req.session.user)
	{
		res.locals.userRole  = req.session.user.userRole;
		res.locals.user  = req.session.user;
	}
   next();
});
app.get('/',function (req, res) {
	res.render('index');
});
app.post('/login', function (req, res) {
	var userModel = require('models/user');
	userModel.findOne({email:req.body.email},{_id:1,firstName:1,email:1,hash:1,userRole:1},function (err, doc) {
        if (err) 
		{
			res.status(200).send({"status":"0","messsage":"Email is not exists!"});
		}
		else
		{
			const bcrypt = require('bcrypt'); 	
			bcrypt.compare(req.body.pass,doc.hash, function(err, ress) {
				// res == true
				if(ress){
					req.session.user = {firstName:doc.firstName,userEmail:doc.email,userRole:doc.userRole,userId:doc._id};
					res.status(200).send({"status":"1","messsage":"login successfully!"});
				}
				else
				{
					res.status(200).send({"status":"0","messsage":"Email or password wrong!"});
				}
			});		
		}
    });	
});
app.get('/logout', function (req, res) {
	delete req.session.user;
	res.redirect('/');
});
app.use(errorHandler);
app.listen(config.port, () => {
    console.log('Server is up and running on port number ' + config.port);
});
