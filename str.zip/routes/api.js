/**ROUTE APIs. */
var express = require('express')
var router = express.Router();
router.use(function(req, res, next) {
	next();
});
router.use('/story', require('controllers/story.controller'));
module.exports = router;