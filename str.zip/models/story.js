var mongoose = require('mongoose');
var Schema = mongoose.Schema;
//status 0 draft 1 publish
var StorySchema = new Schema({
    title: {type: String, required: true, max: 100},
    slug: {type: String, required: true},
    authorId: {type: String, required: true,default: 1},
    content: {type: String, required: true},
    status: {type: Number, required: true,default: 1},
    addedOn: {type: Date, required: true,default: new Date()},
    updatedOn: {type: Date,default: new Date()},
});
// Export the model
module.exports = mongoose.model('Story', StorySchema);