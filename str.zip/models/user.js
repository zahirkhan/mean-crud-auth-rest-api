var mongoose = require('mongoose');
var Schema = mongoose.Schema;
//status 0 draft 1 publish
var userSchema = new Schema({
    firstName: {type: String, required: true, max: 100},
    lastName: {type: String,max: 100},
    email: {type: String, required: true, max: 100},
    hash: {type: String, required: true},
    userRole: {type: String, required: true,default: 'author'},
    status: {type: Number, required: true,default: 0},
    addedOn: {type: Date, required: true,default: new Date()},
    updatedOn: {type: Date,default: new Date()},
});
// Export the model
module.exports = mongoose.model('user', userSchema);