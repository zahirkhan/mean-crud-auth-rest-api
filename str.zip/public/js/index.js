storyApp.controller('storyController', ['$scope', '$http','$routeParams',function($scope, $http,$routeParams) 
{
   $scope.param = $routeParams;
   $scope.currentPage = 1;
   $scope.posts = [];    
   $scope.userfrm = {email:'admin@gmail.com',password:123456};       
   $scope.getStories = function(page){
	   $scope.currentPage = page || 1;
	   $scope.listLoader = true;
	   $http({
        method: 'GET',
		headers : {
            "Content-Type":"application/json",
            "Authorization" : 'Bearer '+$scope.$parent.token
        },
        url: '/api/story/'+$scope.currentPage
		}).then(function success(response) {
			$scope.listLoader = false;
			responsearr = response.data;
			$scope.posts = responsearr.posts;
			$scope.totalCount = responsearr.totalCount;
		}, function error(response) {
			$scope.listLoader = false;
			$scope.posts = [];
		});
   };
   $scope.getStory = function()
   {	
	
	   $scope.listLoader = true;
	   $http({
        method: 'GET',
		headers : {
            "Content-Type":"application/json",
            "Authorization" : 'Bearer '+$scope.$parent.token
        },
        url: '/api/story/post/'+$scope.param.slug
		}).then(function success(response) {
			$scope.listLoader = false;
			responsearr = response.data;
			$scope.post = responsearr.post;
		}, function error(response) {
			$scope.listLoader = false;
			$scope.post = {};
		});
   }; 
   $scope.getStoryEdit = function()
   {	
	
	   $scope.listLoader = true;
	   $http({
        method: 'GET',
		headers : {
            "Content-Type":"application/json",
            "Authorization" : 'Bearer '+$scope.$parent.token
        },
        url: '/api/story/'+$scope.param.id
		}).then(function success(response) {
			$scope.listLoader = false;
			responsearr = response.data;
			$scope.post = responsearr.post;
		}, function error(response) {
			$scope.listLoader = false;
			$scope.post = {};
		});
   };
   $scope.updateStatusConfirm = function (index) {
	   if(angular.isDefined($scope.posts[index])){
		   let st = $scope.posts[index].status != 1 ? 'publish' : 'draft';
		   $scope.confirmIndex = index;
		   $scope.confirmMessage = "Are you sure to change status to "+st+'?';
		   $scope.openModal('sm');		   
	   }
   };
   $scope.resetPost = function () {
	   $scope.post = {title:'',content:'',};
   };
   $scope.editPost = function () {
	   $scope.postErrorMessage = '';
	   $scope.postLoader = true;
	   $http({
        method: 'PUT',
		headers : {
            "Content-Type":"application/json",
            "Authorization" : 'Bearer '+$scope.$parent.token
        },
        data:$scope.post,
        url: '/api/story/'+$scope.post._id
		}).then(function success(response) {
			responsearr = response.data;
			if(responsearr.status != 1){
				$scope.postLoader = false;
				$scope.postErrorMessage = responsearr.message;
			}
			else
			{
				window.location.href = '/';
			}
		}, function error(response) {
			$scope.postLoader = false;
		});
   };
   $scope.addPost = function () {
	   $scope.postErrorMessage = '';
	   $scope.postLoader = true;
	   $http({
        method: 'POST',
		data:$scope.post,        
		headers : {
            "Content-Type":"application/json",
            "Authorization" : 'Bearer '+$scope.$parent.token
        },
		url: '/api/story/'
		}).then(function success(response) {
			responsearr = response.data;
			if(responsearr.status != 1){
				$scope.postLoader = false;
				$scope.postErrorMessage = responsearr.message;
			}
			else
			{
				window.location.href = '/';
			}
		}, function error(response) {
			$scope.postLoader = false;
		});
   };
	$scope.openModal = function (size) {
    var modalInstance = $uibModal.open({
      animation: true,
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-body',
      templateUrl: 'confirmModal.html',
      controller: 'ModalInstanceCtrl',
      controllerAs: 'pc',
      size: size,
      resolve: {
        data: function () {
          return pc.confirmMessage;
        }
      }
    });
    modalInstance.result.then(function () {
      alert("now I'll close the modal");
    });
  };
}]);
/*storyApp.controller('mainController', ['$scope', '$http', function($scope, $http) 
{

    $scope.userfrm = {email:'ss'};
    // when landing on the page, get all comments and show them
    $http({
        method: 'GET',
        url: '/api/comments/fetchAll'
    }).then(function success(response) {
        console.log(response.data);
        $scope.comments = response.data;
    }, function error(response) {
        console.log('Error: ' + response.data);
    });
    // when submitting the add form, send the text to the node API
    $scope.createComment = function() {
        var userName = $scope.formData.userName;
        var comment = $scope.formData.comment;

        if (userName != null && comment != null && userName.trim().length != 0 && comment.trim().length != 0) {
            $http({
                method: 'POST',
                data: $scope.formData,
                url: '/api/comments/save'
            }).then(function success(response) {
                $scope.formData = {}; // clear the form so our user is ready to enter another
                $scope.comments = response.data;
                console.log(response.data);
            }, function error(response) {
                console.log('Error: ' + response.data);
            });
        } else {
            alert("Either UserName or Comment is empty")
        }
    };

    // delete a comment after checking it
    $scope.deleteComment = function(id) {
        $http({
            method: 'DELETE',
            url: '/api/comments/delete/' + id
        }).then(function success(response) {
            console.log(response.data);
            $scope.comments = response.data;
        }, function error(response) {
            console.log('Error: ' + response.data);
        });
    };
}]);*/